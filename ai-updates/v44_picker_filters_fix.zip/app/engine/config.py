# app/engine/config.py
# ============================================================
# УНИВЕРСАЛЬНЫЙ ДВИЖОК CRUD-ТАБЛИЦ — конфигурация.
#
# Идея: вместо того чтобы на каждую справочную таблицу (материалы,
# бренды, категории и т.д.) писать отдельный роутер + отдельный
# Alpine-шаблон вручную, мы один раз описываем таблицу декларативно
# через TableConfig — а движок (engine/api.py + engine/page.py) сам
# генерирует JSON API и HTML-страницу со списком+модалкой.
#
# Что покрывает движок:
#  - обычные поля (текст, число)
#  - computed_pairs — пара полей, взаимно пересчитываемых по формуле
#    (пример: price_excl_vat <-> price_incl_vat через vat_rate)
#  - relations — внешний ключ, отображаемый как выпадающий список
#    и как "живая ссылка" (имя связанной записи, а не голый ID)
#
# Чего движок НЕ покрывает (и не должен) — это осознанно:
#  - каскадные пересчёты между разными документами (продукт → спека
#    → заказ) — слишком специфичная бизнес-логика
#  - составные документы (заказ, инвойс) со своими правилами
#  - снапшоты (расчётные факты, которые не должны быть "живыми
#    ссылками") — для таких сценариев пишем отдельный код, движок
#    только для простых источников истины (справочников)
# ============================================================

from dataclasses import dataclass, field
from typing import Any, Literal, Optional
from sqlmodel import SQLModel


FieldWidget = Literal["text", "number", "select"]


@dataclass
class FieldConfig:
    """Одно поле формы/списка."""
    name: str                      # имя атрибута в модели, например "short_name"
    label: str                     # подпись на русском для формы/списка
    widget: FieldWidget = "text"
    required: bool = False
    placeholder: str = ""
    in_list: bool = True           # показывать в таблице списка
    list_width: Optional[str] = None   # например "26%" или "100px"
    searchable: bool = False       # участвует в текстовом поиске (q=...)
    search_toggle: bool = True     # если searchable=True и на таблице включены
                                    # enable_search_toggles — показывать ли для
                                    # этого поля отдельный чекбокс "искать по …"
                                    # (True) или включать его в поиск всегда,
                                    # без отдельного управления (False)
    search_default: bool = True    # если search_toggle=True — состояние чекбокса
                                    # при первой загрузке страницы (True — отмечен,
                                    # False — снят; человек может переключить вручную,
                                    # выбор держится, пока страница открыта)
    is_numeric: bool = False       # для выравнивания по правому краю и форматирования
    in_form: bool = True           # показывать в форме модалки (по умолчанию — да)
    form_width: Optional[str] = None   # фиксированная ширина поля в форме, например "140px";
                                        # если не задано — поле растягивается на всю доступную ширину ряда
    default: Any = None            # значение по умолчанию при создании новой записи
                                    # (если None — используется 0 для числовых, '' для текстовых)
    readonly: bool = False         # поле показывается в форме как обычный текст,
                                    # не как input — редактировать нельзя ни через
                                    # форму, ни через API (см. update_item в api.py)
    virtual: bool = False          # поле НЕ хранится в модели/БД вообще — не
                                    # передаётся в create/update, не сериализуется
                                    # из instance. Значение подтягивается на фронте
                                    # отдельным запросом (см. source_constant_key)
                                    # и показывается как readonly "живая ссылка".
                                    # Пример: ставка НДС у материала — общая для
                                    # всех, хранится только в constants, но должна
                                    # быть видна в карточке.
    source_constant_key: Optional[str] = None  # для virtual-полей: ключ константы
                                    # в справочнике constants, откуда фронт берёт
                                    # значение для отображения в форме/списке.


@dataclass
class ComputedPair:
    """
    Пара полей, взаимно пересчитываемых друг из друга по формуле.
    Пример: цена без НДС <-> цена с НДС, через ставку НДС.

    formula="vat" — единственный встроенный тип пока. Формула:
        field_b = field_a * (1 + rate / 100)
        field_a = field_b / (1 + rate / 100)
    Новые формулы (наценка, скидка) добавляются в engine/formulas.py
    по мере реальной потребности — не заранее.

    Источник ставки — ровно один из двух:
      - rate_field: имя поля модели (ставка хранится в самой записи,
        как раньше у Material.vat_rate)
      - rate_constant_key: ключ в справочнике constants (ставка —
        общая "живая ссылка", не хранится в записи вообще; пример —
        vat_rate после отказа от per-material поля). Значение
        подгружается на бэкенде из таблицы constant при пересчёте,
        и на фронте — при открытии формы, показывается как readonly.
    Если задан rate_constant_key — rate_field не используется как
    источник данных, но по-прежнему нужен как имя, под которым
    ставка живёт в editing на фронте (чтобы JS-пересчёт работал
    единообразно что для поля модели, что для константы).
    """
    field_a: str
    field_b: str
    rate_field: str
    rate_constant_key: Optional[str] = None
    formula: Literal["vat"] = "vat"
    label_a: str = ""
    label_b: str = ""
    label_rate: str = ""


@dataclass
class Relation:
    """
    Связь с другой справочной таблицей — внешний ключ, показываемый
    как выпадающий список в форме и как имя (не ID) в списке.
    "Живая ссылка" в терминах проекта: показывается текущее имя
    связанной записи, обновляется само при переименовании.
    """
    field: str                     # например "brand_id"
    target_table: str              # ключ таблицы в TABLE_REGISTRY, например "brand"
    display_field: str = "name"    # какое поле связанной записи показывать
    label: str = ""


@dataclass
class FormRow:
    """
    Один визуальный ряд формы — список имён полей, которые должны
    отображаться рядом друг с другом (а не каждое на отдельной строке).

    Если в ряду 2+ поля — рендерится как flex-контейнер (.field-row
    для обычных полей или .price-pair, если хотя бы одно поле ряда
    входит в computed_pairs). Поля, не перечисленные ни в одном
    FormRow, идут каждое отдельным рядом — по порядку объявления в
    TableConfig.fields.
    """
    field_names: list[str] = field(default_factory=list)


@dataclass
class Hierarchy:
    """
    Помечает таблицу как один уровень дерева drill-down (вместо
    обычного плоского списка движка). Пример: kit_group -> kit_section
    -> kit — три TableConfig, каждый со своим Hierarchy.

    parent_field: имя FK-поля в МОДЕЛИ ЭТОЙ таблицы, указывающего на
        родителя (например "kit_group_id" у kit_section). None у
        корневого уровня (kit_group ни на что не ссылается).
    parent_key: ключ родительской таблицы в TABLE_REGISTRY/ALL_TABLES
        (например "kit_group"). None у корневого уровня.
    child_key: ключ дочерней таблицы — того, что открывается по клику
        на строку этого уровня (например у kit_group это "kit_section").
        None у последнего уровня (kit) — там клик по строке ведёт не
        вглубь дерева, а на отдельную страницу-карточку (см.
        TableConfig.edit_mode).
    root_label: подпись крошки самого верхнего уровня, показывается
        всегда первой в цепочке крошек (например "Группы").
    """
    parent_field: Optional[str] = None
    parent_key: Optional[str] = None
    child_key: Optional[str] = None
    root_label: str = ""

    def is_root(self) -> bool:
        return self.parent_key is None


@dataclass
class TableConfig:
    """Полное декларативное описание одной таблицы для движка."""
    key: str                       # уникальный ключ, например "material"
    model: type[SQLModel]
    title: str                     # заголовок страницы, например "Материалы"
    title_singular: str            # для модалки, например "материал"
    fields: list[FieldConfig] = field(default_factory=list)
    computed_pairs: list[ComputedPair] = field(default_factory=list)
    relations: list[Relation] = field(default_factory=list)
    form_rows: list[FormRow] = field(default_factory=list)
    search_placeholder: str = "Поиск…"
    enable_search_toggles: bool = False
    # Если True — на странице сверху под строкой поиска показываются
    # чекбоксы "искать по <label>" для каждого searchable-поля, и
    # пользователь может включать/выключать поля поиска по отдельности.
    # Общий принцип поиска (искать по всем searchable через ?q=) не
    # меняется — эта опция лишь добавляет фильтр по конкретным полям
    # поверх него, через ?q=...&search_fields=name1&search_fields=name2.
    allow_create: bool = True      # False — кнопка "+ Добавить" скрыта, POST
                                    # эндпоинт запрещён (422). Для справочников,
                                    # где набор записей фиксирован (constants —
                                    # ключи задаются только через seed при старте).
    allow_delete: bool = True      # False — кнопка "Удалить" в модалке скрыта,
                                    # DELETE эндпоинт запрещён (422).
    delete_mode: Literal["hard", "soft", "simple"] = "hard"
                                    # "hard" — DELETE удаляет строку физически сразу
                                    #     (поведение по умолчанию, как раньше без
                                    #     soft_delete=True).
                                    # "soft" — модель имеет поле is_deleted. Кнопка в
                                    #     модалке становится "Удалить"/"Отменить"
                                    #     (переключает флаг, не удаляет строку), в
                                    #     первой колонке списка — точка-индикатор
                                    #     статуса. Физическое удаление — отдельно,
                                    #     через purge-обработчик (app/processors).
                                    #     Это прежнее soft_delete=True.
                                    # "simple" — для узлов дерева (Hierarchy) без
                                    #     внешних ссылок на них: DELETE удаляет
                                    #     строку физически, но только если у неё нет
                                    #     дочерних записей (см. hierarchy.child_key) —
                                    #     иначе 422 с понятным сообщением. Синхронная
                                    #     проверка count(), без processor.
    hierarchy: Optional["Hierarchy"] = None
                                    # None — обычная плоская таблица (текущее
                                    # поведение движка не меняется). Заполнено —
                                    # таблица рендерится как один уровень drill-down
                                    # дерева вместо обычного списка (см. Hierarchy).
    edit_mode: Literal["modal", "own_page", "items_modal"] = "modal"
                                    # "modal" — редактирование через универсальную
                                    #     модалку движка (как сейчас у всех таблиц).
                                    # "own_page" — клик по строке ведёт на отдельную
                                    #     страницу-карточку вне движка — зарезервировано
                                    #     на будущее (для kit сейчас используется
                                    #     "items_modal" ниже, не own_page).
                                    # "items_modal" — модалка вместо обычной формы
                                    #     полей показывает СПИСОК дочерних записей
                                    #     другой таблицы (items_source_table_key) —
                                    #     отфильтрованных по текущей записи через её
                                    #     hierarchy.parent_field — плюс кнопку
                                    #     "Добавить", открывающую простую форму
                                    #     создания новой дочерней записи. Ввёдено для
                                    #     kit: клик по комплекту показывает состав
                                    #     (KitItem — материал+количество), а не
                                    #     форму переименования комплекта. НЕ
                                    #     drill-down уровень дерева — kit_item не
                                    #     появляется в hierarchy.child_key/LEVELS,
                                    #     это самостоятельный, не встроенный в дерево
                                    #     список внутри модалки конкретного узла.
    items_source_table_key: Optional[str] = None
                                    # Обязательно при edit_mode="items_modal" — ключ
                                    # TableConfig в ALL_TABLES, чьи записи показывает
                                    # модалка состава (для kit — "kit_item"). Эта
                                    # дочерняя таблица должна иметь свой hierarchy с
                                    # parent_field, указывающим на FK к текущей
                                    # записи (kit_item.hierarchy.parent_field ==
                                    # "kit_id") — так модалка сможет и загрузить
                                    # список (?parent_id={editing.id}), и создать
                                    # новую запись с проставленным FK, переиспользуя
                                    # тот же универсальный механизм, что и drill-down
                                    # между уровнями дерева (см. Hierarchy).

    def field_names(self) -> list[str]:
        """Имена полей, реально хранящихся в модели/БД — используется
        для сериализации instance и для фильтрации payload при
        create/update. Virtual-поля (см. FieldConfig.virtual)
        намеренно исключены: для них нет атрибута в модели."""
        return [f.name for f in self.fields if not f.virtual]

    def searchable_fields(self) -> list[str]:
        return [f.name for f in self.fields if f.searchable]

    def toggleable_search_fields(self) -> list[FieldConfig]:
        """Поля, для которых показывается отдельный чекбокс поиска
        (searchable=True и search_toggle=True)."""
        return [f for f in self.fields if f.searchable and f.search_toggle]

    def always_searched_fields(self) -> list[str]:
        """Searchable-поля, которые ищутся всегда, независимо от
        состояния чекбоксов (searchable=True, но search_toggle=False)."""
        return [f.name for f in self.fields if f.searchable and not f.search_toggle]
